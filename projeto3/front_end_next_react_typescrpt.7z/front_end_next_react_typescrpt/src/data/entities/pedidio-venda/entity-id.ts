export type EntityId = number | null
