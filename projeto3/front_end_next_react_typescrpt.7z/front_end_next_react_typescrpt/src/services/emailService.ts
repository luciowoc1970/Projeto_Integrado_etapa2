export const emailService = {
  sendPasswordResetEmail: async (email: string, resetToken: string): Promise<void> => {
    // Implementar envio de email de reset de senha
  }
};