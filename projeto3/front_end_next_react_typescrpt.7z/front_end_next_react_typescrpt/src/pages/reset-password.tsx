import ResetPasswordForm from '../components/ResetPasswordForm';

const ResetPassword: React.FC = () => {
  return <ResetPasswordForm />;
}

export default ResetPassword;