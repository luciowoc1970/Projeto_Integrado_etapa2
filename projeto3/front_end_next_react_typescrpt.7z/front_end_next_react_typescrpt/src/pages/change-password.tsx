import ChangePasswordForm from '../components/ChangePasswordForm';

const ChangePassword: React.FC = () => {
  return <ChangePasswordForm />;
}

export default ChangePassword;